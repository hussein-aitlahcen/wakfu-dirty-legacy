-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           5.6.20 - MySQL Community Server (GPL)
-- Serveur OS:                   Win32
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Export de la structure de la base pour akfu
CREATE DATABASE IF NOT EXISTS `akfu` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `akfu`;


-- Export de la structure de table akfu. account
CREATE TABLE IF NOT EXISTS `account` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL DEFAULT '',
  `adminLevel` int(11) NOT NULL DEFAULT '0',
  `creation_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_connection` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(50) NOT NULL DEFAULT '0.0.0.0',
  `online` tinyint(4) NOT NULL DEFAULT '0',
  `banned_until` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `pseudo` (`pseudo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Export de données de la table akfu.account: ~0 rows (environ)
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`, `name`, `pseudo`, `password`, `mail`, `adminLevel`, `creation_date`, `last_connection`, `last_ip`, `online`, `banned_until`) VALUES
	(0, 'Smarken', 'Smarken024', 'test', 'rien@rien.com', 10, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0.0.0.0', 0, '0000-00-00 00:00:00');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
